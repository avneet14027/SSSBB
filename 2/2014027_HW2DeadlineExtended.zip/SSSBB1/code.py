import random as rand
import matplotlib.pyplot as plt
import numpy as np

#0 --> inactive
#1 --> active
c = 0.01
delT = 0.1
P = float(c*delT)
steps = [0]
no_of_inactive_molecules = [200]
molecules = []
giant_array = []
new_array = []
final_histogram_array = []

def create_molecules():
	global molecules
	molecules = [[i,0] for i in range(200)]

def generate_point():
	global steps,no_of_inactive_molecules,molecules,giant_array
	steps.append(steps[-1]+100)
	no_of_inactive_molecules.append(sum(x[1]==0 for x in molecules))
	#print no_of_inactive_molecules
	

def reset():
	global steps,no_of_inactive_molecules,molecules
	create_molecules()
	steps = [0]
	no_of_inactive_molecules = [200]
	
def mc_simulation():
	plt.figure()
	global steps,no_of_inactive_molecules,molecules
	count = 1
	for i in range(10):
		step_counter=0
		reset()
		for j in range(2000):
			step_counter+=1
			random_molecule = (rand.randrange(0,199))
			random = rand.uniform(0,float(2*P))
			if(random<=P):
				molecules[random_molecule][1]=1
			if(step_counter==100):
				step_counter=0
				generate_point()
		#print steps,no_of_inactive_molecules
		plot_graph(i)
		app = [[steps[i],no_of_inactive_molecules[i]] for i in range(len(steps))]
		new_array.append(app)
		plt.plot(steps, no_of_inactive_molecules, marker='^',label='${count} MC RUN$'.format(count=count))
		plt.legend(loc='best')
		plt.ylabel('Number of inactive X molecules')
		plt.xlabel('Number of MC steps')
		count+=1	
	plt.savefig('big_plot3.png')
	#plt.show()
	plt.close()
		

def plot_variance_plot():
	xaxis = [i for i in range(10)]
	print len(new_array),len(new_array[1])
	#for j in range(21):
	#	append_arr = [[array[j][0],array[j][1]] for array in new_array]
	#	giant_array.append(append_arr)
	for j in range(21):
		append_arr = [array[j][1] for array in new_array]
		giant_array.append(append_arr)
	print len(giant_array)
	for i in range(len(giant_array)):
		plt.figure()
		frequencies = giant_array[i]
		pos = np.arange(len(xaxis))
		width = 1
		ax = plt.axes()
		ax.set_xticks(pos + (width / 2))
		ax.set_xticklabels(xaxis)
		plt.bar(pos, frequencies, width, color='r')
		name = 'hist' + str(i) + '.png'
		plt.savefig(name)
		plt.close()
	variance_array = []
	for array in giant_array:
		#print array
		var = np.var(array)
		variance_array.append(var)
	x = max(variance_array)
	y = variance_array.index(x) * 100
	print "max variance: ",x," time: (MC steps)",y
	fig = plt.figure() 
	ax = fig.add_subplot(111)
	plt.plot(steps,variance_array)
	for xy in zip(steps, variance_array):                                       
    		ax.annotate('(%s, %s)' % xy, xy=xy, textcoords='data') 
	plt.xlabel('mc steps')
	plt.ylabel('variance')
	plt.savefig('variance_plt3')
	plt.close()
def plot_graph(i):
	fig = plt.figure() 
	ax = fig.add_subplot(111)
	plt.plot(steps,no_of_inactive_molecules,marker='o')	
	for xy in zip(steps, no_of_inactive_molecules):                                       
    		ax.annotate('(%s, %s)' % xy, xy=xy, textcoords='data') 
	plt.grid()
	plt.ylabel('Number of inactive X molecules')
	plt.xlabel('Number of MC steps')
	#plt.show()
	fname = str(i)+'.png'
	plt.savefig(fname)
	plt.close()

if __name__ == "__main__":
	create_molecules()
	mc_simulation()
	plot_variance_plot()
